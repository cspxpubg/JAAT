JAAT — Chart of Accounts APK Builder

اس پیکج میں اصل JAAT Chart of Accounts HTML شامل ہے، Employee & Task Manager نہیں۔
WhatsApp پر غیر حاضری کی اطلاع اور تنخواہ/ادائیگی کی تفصیل شیئر کرنے کے فیچر بھی شامل ہیں۔

GitHub پر اس ZIP کو extract کرکے تمام فائلیں repository میں upload کریں۔ پھر Actions tab کھولیں، Build JAAT Chart of Accounts APK منتخب کریں اور Run workflow دبائیں۔ کامیاب build کے بعد JAAT-Chart-of-Accounts-APK artifact download کریں۔

نوٹ: APK GitHub Actions چلنے کے بعد بنے گی؛ یہ ZIP خود APK نہیں ہے۔
